favorite_number = 7

message = f"My favorite number is {favorite_number}!"

print(message)
