print (4+4)
print (2*4)
print (int(16/2))
print (10-2)